public class Main {
    public static void main(String[] args) {
        Point a = new Point(5,6);
        Point b = new Point(3,8);
        System.out.println(a.distanceTo(b));

        Triangle abc = new Triangle(new Point(2,7), new Point(2,2), new Point(8,2));
        System.out.println(abc.getArea());


    }
}
